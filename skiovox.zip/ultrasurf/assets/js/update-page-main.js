$("#link1").click(function () {
    chrome.tabs.create({url: "http://www.technipages.com/google-chrome-prefetch"});
});